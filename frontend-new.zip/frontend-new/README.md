# Frontend - Schichtplaner

React-Anwendung mit TypeScript, Vite und Tabler UI.

## Entwicklung

```bash
yarn dev      # Development-Server
yarn build    # Production-Build
yarn test     # Tests ausführen
```
