import { Routes, Route } from "react-router-dom";
import { MainTemplate, PageTemplate, LoginTemplate } from "./templates";
import { DemoOverview, TimesheetDemo, LayoutDemo } from "./pages";

function App() {
  return (
    <Routes>
        {/* Login Route */}
        <Route path="/login" element={
          <LoginTemplate title="Kimai Login" subtitle="Verbinden Sie sich mit der Kimai-App">
            <form>
              <div className="mb-3">
                <label className="form-label">Benutzername</label>
                <input type="text" className="form-control" placeholder="admin" />
              </div>
              <div className="mb-3">
                <label className="form-label">Passwort</label>
                <input type="password" className="form-control" placeholder="Br290805" />
              </div>
              <div className="d-grid">
                <button type="submit" className="btn btn-primary">Anmelden</button>
              </div>
            </form>
          </LoginTemplate>
        } />

        {/* Demo Routes */}
        <Route path="/" element={
          <PageTemplate 
            headerTitle="Kimai React Frontend"
            pagePretitle="Demo"
            pageTitle="Dashboard"
            pageSubtitle="Verbunden mit Kimai Docker-App"
          >
            <div className="row">
              <div className="col-12">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Willkommen beim Kimai React Frontend</h3>
                  </div>
                  <div className="card-body">
                    <p>Dieses Frontend ist mit der Kimai Docker-App über Playwright verbunden.</p>
                    <p>Verwenden Sie die Navigation, um verschiedene Demo-Seiten zu erkunden.</p>
                  </div>
                </div>
              </div>
            </div>
          </PageTemplate>
        } />

        <Route path="/demo-overview" element={
          <MainTemplate headerTitle="Demo Overview">
            <DemoOverview />
          </MainTemplate>
        } />

        <Route path="/timesheet-demo" element={
          <MainTemplate headerTitle="Timesheet Demo">
            <TimesheetDemo />
          </MainTemplate>
        } />

        <Route path="/layout-demo" element={
          <MainTemplate headerTitle="Layout Demo">
            <LayoutDemo />
          </MainTemplate>
        } />

        {/* 404 Route */}
        <Route path="*" element={
          <div className="page page-center">
            <div className="container container-tight py-4">
              <div className="text-center">
                <h1>404</h1>
                <p>Seite nicht gefunden</p>
                <a href="/" className="btn btn-primary">Zurück zum Dashboard</a>
              </div>
            </div>
          </div>
        } />
      </Routes>
  );
}

export default App;
