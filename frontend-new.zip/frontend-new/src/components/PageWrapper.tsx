import React from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";

interface PageWrapperProps {
  children: React.ReactNode;
  headerTitle?: string;
  headerActions?: React.ReactNode;
}

const PageWrapper: React.FC<PageWrapperProps> = ({ children, headerTitle, headerActions }) => {
  return (
    <div className="page">
      <Sidebar />
      <div className="page-wrapper">
        <Header title={headerTitle}>{headerActions}</Header>
        <div className="page-body">
          <div className="container-fluid">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PageWrapper; 