import React, { useState } from "react";
import Sidebar from "./Sidebar";

const SidebarExample: React.FC = () => {
  const [userPermissions, setUserPermissions] = useState<string[]>(['user']);

  const permissionOptions = [
    { value: 'user', label: 'Benutzer' },
    { value: 'admin', label: 'Administrator' },
    { value: 'super_admin', label: 'Super Administrator' }
  ];

  const handlePermissionChange = (permission: string, checked: boolean) => {
    if (checked) {
      setUserPermissions(prev => [...prev, permission]);
    } else {
      setUserPermissions(prev => prev.filter(p => p !== permission));
    }
  };

  return (
    <div className="d-flex">
      <Sidebar userPermissions={userPermissions} />
      <div className="flex-grow-1 p-4">
        <h2>Sidebar Beispiel</h2>
        <p>Diese Seite zeigt, wie die Sidebar mit verschiedenen Berechtigungen funktioniert.</p>
        
        <div className="card">
          <div className="card-header">
            <h5 className="card-title">Berechtigungen testen</h5>
          </div>
          <div className="card-body">
            <p>Wähle verschiedene Berechtigungen aus, um zu sehen, wie sich die Navigation ändert:</p>
            
            <div className="form-check">
              {permissionOptions.map(option => (
                <div key={option.value} className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id={`permission-${option.value}`}
                    checked={userPermissions.includes(option.value)}
                    onChange={(e) => handlePermissionChange(option.value, e.target.checked)}
                  />
                  <label className="form-check-label" htmlFor={`permission-${option.value}`}>
                    {option.label}
                  </label>
                </div>
              ))}
            </div>
            
            <div className="mt-3">
              <strong>Aktuelle Berechtigungen:</strong> {userPermissions.join(', ')}
            </div>
          </div>
        </div>
        
        <div className="card mt-4">
          <div className="card-header">
            <h5 className="card-title">Navigation Features</h5>
          </div>
          <div className="card-body">
            <ul>
              <li><strong>Berechtigungsbasierte Navigation:</strong> Nur Menüpunkte mit entsprechenden Berechtigungen werden angezeigt</li>
              <li><strong>Externe Links:</strong> Öffnen sich in einem neuen Tab</li>
              <li><strong>Badges:</strong> Zeigen zusätzliche Informationen an (z.B. Anzahl aktiver Zeiterfassungen)</li>
              <li><strong>Deaktivierte Links:</strong> Können für temporär nicht verfügbare Funktionen verwendet werden</li>
              <li><strong>Aktive Navigation:</strong> Der aktuelle Pfad wird automatisch hervorgehoben</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SidebarExample; 