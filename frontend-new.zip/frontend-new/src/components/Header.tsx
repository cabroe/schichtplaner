import React from "react";

interface HeaderProps {
  title?: string;
  children?: React.ReactNode;
}

const Header: React.FC<HeaderProps> = ({ title, children }) => {
  return (
    <header className="navbar navbar-expand-md d-none d-lg-flex d-print-none">
      <div className="container-fluid">
        <h2 className="page-title me-2">{title || ""}</h2>
        <div className="navbar-nav flex-row order-md-last">
          {children}
        </div>
      </div>
    </header>
  );
};

export default Header; 