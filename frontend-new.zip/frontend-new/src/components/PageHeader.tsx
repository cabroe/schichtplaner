import React from "react";

interface PageHeaderProps {
  pretitle?: string;
  title: string;
  subtitle?: string;
}

const PageHeader: React.FC<PageHeaderProps> = ({ pretitle, title, subtitle }) => (
  <div className="page-header d-print-none">
    {pretitle && <div className="page-pretitle">{pretitle}</div>}
    <h2 className="page-title">{title}</h2>
    {subtitle && <div className="page-subtitle text-body-secondary mt-1">{subtitle}</div>}
  </div>
);

export default PageHeader; 