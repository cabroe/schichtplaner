import React from "react";

const RecentActivities: React.FC = () => {
  // Beispiel-Daten
  const activities = [
    { icon: "fas fa-clock", label: "Zeiterfassung gestartet" },
    { icon: "fas fa-check", label: "Projekt abgeschlossen" },
    { icon: "fas fa-user", label: "Benutzer angemeldet" },
  ];
  return (
    <div className="nav-item d-flex align-items-center ms-2 recent-activities">
      {activities.map((a, i) => (
        <span key={i} className="me-2" title={a.label}>
          <i className={a.icon}></i>
        </span>
      ))}
    </div>
  );
};

export default RecentActivities; 