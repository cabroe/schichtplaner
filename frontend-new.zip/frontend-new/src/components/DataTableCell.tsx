import React from "react";

interface DataTableCellProps {
  children: React.ReactNode;
}

const DataTableCell: React.FC<DataTableCellProps> = ({ children }) => (
  <td>{children}</td>
);

export default DataTableCell; 