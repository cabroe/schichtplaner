import React from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  navigationConfig, 
  isNavigationItemActive,
  filterNavigationByPermissions
} from "../config/navigation";
import type { NavigationItem } from "../config/navigation";

interface SidebarProps {
  userPermissions?: string[];
}

const Sidebar: React.FC<SidebarProps> = ({ userPermissions = [] }) => {
  const location = useLocation();
  const currentPath = location.pathname;

  // Filter navigation based on user permissions
  const filteredNavigation = filterNavigationByPermissions(navigationConfig, userPermissions);

  const renderNavigationItem = (item: NavigationItem) => {
    const isActive = isNavigationItemActive(item, currentPath);
    
    if (item.disabled) {
      return (
        <li key={item.id} className="nav-item">
          <span className="nav-link disabled">
            {item.icon && (
              <i className={`nav-icon ${item.icon}`}></i>
            )}
            <span className="nav-text">{item.label}</span>
            {item.badge && (
              <span className="nav-badge">{item.badge}</span>
            )}
          </span>
        </li>
      );
    }

    if (item.external) {
      return (
        <li key={item.id} className="nav-item">
          <a
            href={item.path}
            className="nav-link"
            target="_blank"
            rel="noopener noreferrer"
          >
            {item.icon && (
              <i className={`nav-icon ${item.icon}`}></i>
            )}
            <span className="nav-text">{item.label}</span>
            <i className="fas fa-external-link-alt nav-external-icon"></i>
          </a>
        </li>
      );
    }

    return (
      <li key={item.id} className="nav-item">
        <Link
          to={item.path}
          className={`nav-link ${isActive ? 'active' : ''}`}
        >
          {item.icon && (
            <i className={`nav-icon ${item.icon}`}></i>
          )}
          <span className="nav-text">{item.label}</span>
          {item.badge && (
            <span className="nav-badge">{item.badge}</span>
          )}
        </Link>
      </li>
    );
  };

  return (
    <aside className="navbar navbar-vertical navbar-expand-lg" data-bs-theme="dark">
      <div className="container-fluid">
        {/* Logo/Brand */}
        <h1 className="navbar-brand d-none d-lg-inline-flex">Kimai React</h1>
        
        {/* Navigation */}
        <nav className="mt-4">
          {filteredNavigation.map((section) => (
            <div key={section.id} className="nav-section">
              {section.title && (
                <div className="nav-section-title">{section.title}</div>
              )}
              <ul className="nav flex-column">
                {section.items.map(renderNavigationItem)}
              </ul>
            </div>
          ))}
        </nav>
        
        {/* User Menu */}
        <div className="mt-auto">User</div>
      </div>
    </aside>
  );
};

export default Sidebar; 