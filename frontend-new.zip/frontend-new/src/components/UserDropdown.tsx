import React, { useState } from "react";

const UserDropdown: React.FC = () => {
  const [open, setOpen] = useState(false);
  return (
    <div className="dropdown ms-2">
      <button className="btn btn-outline-secondary dropdown-toggle" onClick={() => setOpen(!open)}>
        <span className="avatar bg-primary me-2">AD</span> admin
      </button>
      {open && (
        <ul className="dropdown-menu show" style={{ position: 'absolute' }}>
          <li><a className="dropdown-item" href="#">Profil</a></li>
          <li><a className="dropdown-item" href="#">Einstellungen</a></li>
          <li><hr className="dropdown-divider" /></li>
          <li><a className="dropdown-item" href="#">Abmelden</a></li>
        </ul>
      )}
    </div>
  );
};

export default UserDropdown; 