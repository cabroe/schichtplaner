import React from "react";

interface DataTableRowProps {
  children: React.ReactNode;
}

const DataTableRow: React.FC<DataTableRowProps> = ({ children }) => (
  <tr>{children}</tr>
);

export default DataTableRow; 