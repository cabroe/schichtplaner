import React from "react";

const Footer: React.FC = () => (
  <footer className="footer footer-transparent d-print-none mt-auto">
    <div className="container-fluid text-center py-3">
      <span className="text-muted">&copy; {new Date().getFullYear()} Kimai React Demo</span>
    </div>
  </footer>
);

export default Footer; 