# Layout System

Das Layout-System implementiert die Kimai-Struktur in React-Komponenten.

## Übersicht

Das Layout-System besteht aus mehreren Komponenten, die zusammen die typische Kimai-Seitenstruktur bilden:

```
<div class="page">
  <aside class="navbar navbar-vertical">
    <!-- Sidebar -->
  </aside>

  <header class="navbar navbar-expand-md">
    <!-- Header -->
  </header>

  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="page-header">
        <!-- Seitenkopf -->
      </div>

      <div class="page-body">
        <div class="container-fluid">
          <div class="row row-cards">
            <!-- Hauptinhalt -->
          </div>
        </div>
      </div>

      <footer class="footer footer-transparent">
        <!-- Fußzeile -->
      </footer>
    </div>
  </div>
</div>
```

## Komponenten

### PageLayout

Die Hauptkomponente, die alle anderen Layout-Komponenten zusammenbringt.

```tsx
import { PageLayout } from '../components/Layout';

<PageLayout
  pageTitle="Dashboard"
  pageSubtitle="Übersicht über Ihre Arbeitszeiten"
  pageActions={<button className="btn btn-primary">Aktion</button>}
  breadcrumbs={[
    { label: "Dashboard", path: "/" }
  ]}
  userPermissions={['user', 'admin']}
  showFooter={true}
  footerTransparent={false}
>
  {/* Seiteninhalt */}
</PageLayout>
```

**Props:**
- `children`: React.ReactNode - Der Hauptinhalt der Seite
- `userPermissions`: string[] - Benutzerberechtigungen für die Sidebar
- `pageTitle`: string - Titel der Seite
- `pageSubtitle`: string - Untertitel der Seite
- `pageActions`: React.ReactNode - Aktionen im Seitenkopf
- `breadcrumbs`: Array - Breadcrumb-Navigation
- `showFooter`: boolean - Footer anzeigen/verstecken
- `footerTransparent`: boolean - Transparenter Footer
- `footerContent`: React.ReactNode - Custom Footer-Inhalt

### PageHeader

Komponente für den Seitenkopf mit Titel, Breadcrumbs und Aktionen.

```tsx
import { PageHeader } from '../components/Layout';

<PageHeader
  title="Dashboard"
  subtitle="Übersicht über Ihre Arbeitszeiten"
  actions={<button className="btn btn-primary">Aktion</button>}
  breadcrumbs={[
    { label: "Dashboard", path: "/" }
  ]}
/>
```

**Props:**
- `title`: string - Titel der Seite
- `subtitle`: string - Untertitel der Seite
- `actions`: React.ReactNode - Aktionen (Buttons, etc.)
- `breadcrumbs`: Array - Breadcrumb-Navigation

### PageBody

Komponente für den Hauptinhalt der Seite.

```tsx
import { PageBody } from '../components/Layout';

<PageBody className="custom-class">
  {/* Seiteninhalt */}
</PageBody>
```

**Props:**
- `children`: React.ReactNode - Der Inhalt
- `className`: string - Zusätzliche CSS-Klassen

### Footer

Komponente für die Fußzeile.

```tsx
import { Footer } from '../components/Layout';

<Footer transparent={true}>
  <p>Custom Footer Content</p>
</Footer>
```

**Props:**
- `children`: React.ReactNode - Footer-Inhalt
- `transparent`: boolean - Transparenter Footer

## Verwendung

### Einfache Seite

```tsx
import { PageLayout } from '../components/Layout';

const SimplePage = () => {
  return (
    <PageLayout pageTitle="Einfache Seite">
      <div className="card">
        <div className="card-body">
          <h3>Willkommen!</h3>
          <p>Dies ist eine einfache Seite mit dem Kimai-Layout.</p>
        </div>
      </div>
    </PageLayout>
  );
};
```

### Komplexe Seite mit allen Features

```tsx
import { PageLayout } from '../components/Layout';

const DashboardPage = () => {
  const pageActions = (
    <>
      <button className="btn btn-primary">
        <i className="fas fa-plus me-2"></i>
        Neue Zeiterfassung
      </button>
      <button className="btn btn-outline-secondary">
        <i className="fas fa-download me-2"></i>
        Export
      </button>
    </>
  );

  const breadcrumbs = [
    { label: "Dashboard", path: "/" }
  ];

  return (
    <PageLayout
      pageTitle="Dashboard"
      pageSubtitle="Übersicht über Ihre Arbeitszeiten und Projekte"
      pageActions={pageActions}
      breadcrumbs={breadcrumbs}
      userPermissions={['user', 'admin']}
      showFooter={true}
      footerTransparent={true}
    >
      <section className="content dashboard">
        <div className="row row-cards">
          <div className="col-sm-6 col-lg-3">
            <div className="card">
              <div className="card-body">
                <h3>Statistik</h3>
                <p>Ihre Arbeitszeit heute: 7.5h</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};
```

### Seiten ohne Header

```tsx
const LoginPage = () => {
  return (
    <PageLayout showFooter={false}>
      <div className="container-xl">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card">
              <div className="card-body">
                <h2>Anmelden</h2>
                {/* Login-Formular */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};
```

## Best Practices

1. **Konsistente Struktur**: Verwende immer `PageLayout` als Wrapper
2. **Breadcrumbs**: Definiere Breadcrumbs für bessere Navigation
3. **Aktionen**: Platziere wichtige Aktionen im `pageActions`
4. **Berechtigungen**: Übergebe `userPermissions` für berechtigungsbasierte Navigation
5. **Footer**: Verwende `footerTransparent={true}` für moderne Seiten
6. **Responsive Design**: Nutze Bootstrap-Grid für responsive Layouts

## CSS-Klassen

Das Layout verwendet folgende CSS-Klassen:

- `.page` - Hauptcontainer
- `.navbar-vertical` - Vertikale Sidebar
- `.navbar-expand-md` - Responsive Header
- `.page-wrapper` - Wrapper für Hauptinhalt
- `.page-header` - Seitenkopf
- `.page-body` - Hauptinhalt
- `.row-cards` - Karten-Layout
- `.footer-transparent` - Transparenter Footer

## Integration mit Navigation

Das Layout-System arbeitet nahtlos mit der Navigation-Konfiguration zusammen:

```tsx
// Navigation wird automatisch basierend auf userPermissions gefiltert
<PageLayout userPermissions={['admin', 'user']}>
  {/* Seiteninhalt */}
</PageLayout>
```

## Erweiterungen

### Custom Layout-Komponenten

```tsx
// Custom Layout für spezielle Seiten
const CustomLayout = ({ children, ...props }) => {
  return (
    <PageLayout {...props}>
      <div className="custom-layout">
        {children}
      </div>
    </PageLayout>
  );
};
```

### Layout-Hooks

```tsx
// Hook für Layout-spezifische Logik
const useLayout = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  
  return {
    sidebarCollapsed,
    toggleSidebar: () => setSidebarCollapsed(!sidebarCollapsed)
  };
};
``` 