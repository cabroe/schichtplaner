// Layout Components
// Centralized exports for all layout components

export { default as PageLayout } from './PageLayout';
export { default as PageHeader } from './PageHeader';
export { default as PageBody } from './PageBody';
export { default as Footer } from './Footer'; 