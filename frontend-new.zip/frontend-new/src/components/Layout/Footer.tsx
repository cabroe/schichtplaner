import React from "react";

interface FooterProps {
  children?: React.ReactNode;
  transparent?: boolean;
}

const Footer: React.FC<FooterProps> = ({ children, transparent = false }) => {
  return (
    <footer className={`footer ${transparent ? 'footer-transparent' : ''}`}>
      <div className="container-xl">
        <div className="row text-center align-items-center flex-row-reverse">
          <div className="col-12 col-lg-auto mt-3 mt-lg-0">
            {children || (
              <>
                <ul className="list-inline list-inline-dots mb-0">
                  <li className="list-inline-item">
                    Copyright &copy; 2024
                    <a href="." className="link-secondary">Kimai React</a>.
                    All rights reserved.
                  </li>
                  <li className="list-inline-item">
                    <a href="./changelog.html" className="link-secondary" rel="noopener">
                      v1.0.0
                    </a>
                  </li>
                </ul>
              </>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer; 