import React from "react";
import Sidebar from "../Sidebar";
import Header from "../Header";
import PageHeader from "./PageHeader";
import PageBody from "./PageBody";
import Footer from "./Footer";

interface PageLayoutProps {
  children: React.ReactNode;
  userPermissions?: string[];
  pageTitle?: string;
  pageSubtitle?: string;
  pageActions?: React.ReactNode;
  breadcrumbs?: Array<{
    label: string;
    path?: string;
  }>;
  showFooter?: boolean;
  footerTransparent?: boolean;
  footerContent?: React.ReactNode;
}

const PageLayout: React.FC<PageLayoutProps> = ({ 
  children, 
  userPermissions = [],
  pageTitle,
  pageSubtitle,
  pageActions,
  breadcrumbs = [],
  showFooter = true,
  footerTransparent = false,
  footerContent
}) => {
  return (
    <div className="page">
      <aside className="navbar navbar-vertical">
        <Sidebar userPermissions={userPermissions} />
      </aside>

      <header className="navbar navbar-expand-md">
        <Header />
      </header>

      <div className="page-wrapper">
        <div className="container-fluid">
          {/* Page Header */}
          {pageTitle && (
            <PageHeader
              title={pageTitle}
              subtitle={pageSubtitle}
              actions={pageActions}
              breadcrumbs={breadcrumbs}
            />
          )}

          {/* Page Body */}
          <PageBody>
            {children}
          </PageBody>

          {/* Footer */}
          {showFooter && (
            <Footer transparent={footerTransparent}>
              {footerContent}
            </Footer>
          )}
        </div>
      </div>
    </div>
  );
};

export default PageLayout; 