import React from "react";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  breadcrumbs?: Array<{
    label: string;
    path?: string;
  }>;
}

const PageHeader: React.FC<PageHeaderProps> = ({ 
  title, 
  subtitle, 
  actions, 
  breadcrumbs = [] 
}) => {
  return (
    <div className="page-header">
      <div className="container-xl">
        <div className="row align-items-center">
          <div className="col">
            {/* Breadcrumbs */}
            {breadcrumbs.length > 0 && (
              <div className="page-pretitle">
                {breadcrumbs.map((crumb, index) => (
                  <span key={index}>
                    {index > 0 && <span className="mx-2">/</span>}
                    {crumb.path ? (
                      <a href={crumb.path} className="text-muted">
                        {crumb.label}
                      </a>
                    ) : (
                      <span className="text-muted">{crumb.label}</span>
                    )}
                  </span>
                ))}
              </div>
            )}
            
            {/* Page Title */}
            <h2 className="page-title">
              {title}
            </h2>
            
            {/* Page Subtitle */}
            {subtitle && (
              <div className="page-subtitle">
                {subtitle}
              </div>
            )}
          </div>
          
          {/* Page Actions */}
          {actions && (
            <div className="col-auto ms-auto d-print-none">
              <div className="btn-list">
                {actions}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PageHeader; 