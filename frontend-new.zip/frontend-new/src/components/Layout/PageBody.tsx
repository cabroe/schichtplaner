import React from "react";

interface PageBodyProps {
  children: React.ReactNode;
  className?: string;
}

const PageBody: React.FC<PageBodyProps> = ({ children, className = "" }) => {
  return (
    <div className={`page-body ${className}`}>
      <div className="container-fluid">
        <div className="row row-cards">
          {children}
        </div>
      </div>
    </div>
  );
};

export default PageBody; 