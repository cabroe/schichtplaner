import React from "react";

interface DataTableProps {
  columns: string[];
  children: React.ReactNode;
}

const DataTable: React.FC<DataTableProps> = ({ columns, children }) => (
  <table className="table table-striped">
    <thead>
      <tr>
        {columns.map((col) => (
          <th key={col}>{col}</th>
        ))}
      </tr>
    </thead>
    <tbody>{children}</tbody>
  </table>
);

export default DataTable; 