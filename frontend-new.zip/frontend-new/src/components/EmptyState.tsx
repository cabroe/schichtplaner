import React from "react";

interface EmptyStateProps {
  icon?: string;
  title: string;
  subtitle?: string;
}

const EmptyState: React.FC<EmptyStateProps> = ({ icon = "fas fa-inbox", title, subtitle }) => (
  <div className="empty">
    <div className="empty-icon mb-4">
      <i className={icon} style={{ fontSize: 48 }}></i>
    </div>
    <p className="empty-title">{title}</p>
    {subtitle && <p className="empty-subtitle text-muted">{subtitle}</p>}
  </div>
);

export default EmptyState; 