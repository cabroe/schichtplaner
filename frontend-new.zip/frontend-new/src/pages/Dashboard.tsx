import React from "react";
import PageLayout from "../components/Layout/PageLayout";

const Dashboard: React.FC = () => {
  const pageActions = (
    <>
      <button className="btn btn-primary">
        <i className="fas fa-plus me-2"></i>
        Neue Zeiterfassung
      </button>
      <button className="btn btn-outline-secondary">
        <i className="fas fa-download me-2"></i>
        Export
      </button>
    </>
  );

  const breadcrumbs = [
    { label: "Dashboard", path: "/" }
  ];

  return (
    <PageLayout
      pageTitle="Dashboard"
      pageSubtitle="Übersicht über Ihre Arbeitszeiten und Projekte"
      pageActions={pageActions}
      breadcrumbs={breadcrumbs}
      userPermissions={['user', 'admin']}
    >
      <section className="content dashboard">
        {/* Dashboard Cards */}
        <div className="row row-cards">
          <div className="col-sm-6 col-lg-3">
            <div className="card">
              <div className="card-body">
                <div className="d-flex align-items-center">
                  <div className="subheader">Heute gearbeitet</div>
                </div>
                <div className="h1 mb-3">7.5h</div>
                <div className="d-flex mb-2">
                  <div>Produktivität</div>
                  <div className="ms-auto">
                    <span className="text-green d-inline-flex align-items-center lh-1">
                      7% <i className="fas fa-arrow-up"></i>
                    </span>
                  </div>
                </div>
                <div className="progress progress-sm">
                  <div className="progress-bar bg-primary" style={{ width: "78%" }}></div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-sm-6 col-lg-3">
            <div className="card">
              <div className="card-body">
                <div className="d-flex align-items-center">
                  <div className="subheader">Diese Woche</div>
                </div>
                <div className="h1 mb-3">32.5h</div>
                <div className="d-flex mb-2">
                  <div>Ziel: 40h</div>
                  <div className="ms-auto">
                    <span className="text-yellow d-inline-flex align-items-center lh-1">
                      81% <i className="fas fa-arrow-down"></i>
                    </span>
                  </div>
                </div>
                <div className="progress progress-sm">
                  <div className="progress-bar bg-yellow" style={{ width: "81%" }}></div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-sm-6 col-lg-3">
            <div className="card">
              <div className="card-body">
                <div className="d-flex align-items-center">
                  <div className="subheader">Aktive Projekte</div>
                </div>
                <div className="h1 mb-3">5</div>
                <div className="d-flex mb-2">
                  <div>Projekte</div>
                  <div className="ms-auto">
                    <span className="text-green d-inline-flex align-items-center lh-1">
                      2 neue <i className="fas fa-plus"></i>
                    </span>
                  </div>
                </div>
                <div className="progress progress-sm">
                  <div className="progress-bar bg-green" style={{ width: "100%" }}></div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-sm-6 col-lg-3">
            <div className="card">
              <div className="card-body">
                <div className="d-flex align-items-center">
                  <div className="subheader">Offene Zeiterfassungen</div>
                </div>
                <div className="h1 mb-3">3</div>
                <div className="d-flex mb-2">
                  <div>Zeiterfassungen</div>
                  <div className="ms-auto">
                    <span className="text-red d-inline-flex align-items-center lh-1">
                      <i className="fas fa-clock"></i>
                    </span>
                  </div>
                </div>
                <div className="progress progress-sm">
                  <div className="progress-bar bg-red" style={{ width: "60%" }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="row row-cards">
          <div className="col-lg-8">
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">Letzte Aktivitäten</h3>
              </div>
              <div className="card-body">
                <div className="divide-y">
                  <div className="row">
                    <div className="col-auto">
                      <span className="avatar">JD</span>
                    </div>
                    <div className="col">
                      <div className="text-truncate">
                        <strong>John Doe</strong> hat eine neue Zeiterfassung gestartet
                      </div>
                      <div className="text-muted">vor 2 Minuten</div>
                    </div>
                    <div className="col-auto align-self-center">
                      <div className="badge bg-primary">Projekt A</div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-auto">
                      <span className="avatar">JS</span>
                    </div>
                    <div className="col">
                      <div className="text-truncate">
                        <strong>Jane Smith</strong> hat eine Zeiterfassung beendet
                      </div>
                      <div className="text-muted">vor 15 Minuten</div>
                    </div>
                    <div className="col-auto align-self-center">
                      <div className="badge bg-success">Projekt B</div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-auto">
                      <span className="avatar">MJ</span>
                    </div>
                    <div className="col">
                      <div className="text-truncate">
                        <strong>Mike Johnson</strong> hat ein neues Projekt erstellt
                      </div>
                      <div className="text-muted">vor 1 Stunde</div>
                    </div>
                    <div className="col-auto align-self-center">
                      <div className="badge bg-info">Neu</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-4">
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">Schnellaktionen</h3>
              </div>
              <div className="card-body">
                <div className="d-grid gap-2">
                  <button className="btn btn-primary">
                    <i className="fas fa-play me-2"></i>
                    Zeiterfassung starten
                  </button>
                  <button className="btn btn-outline-secondary">
                    <i className="fas fa-stop me-2"></i>
                    Zeiterfassung stoppen
                  </button>
                  <button className="btn btn-outline-secondary">
                    <i className="fas fa-plus me-2"></i>
                    Neues Projekt
                  </button>
                  <button className="btn btn-outline-secondary">
                    <i className="fas fa-file-export me-2"></i>
                    Bericht exportieren
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Dashboard; 