import React from "react";
import PageWrapper from "../components/PageWrapper";
import PageHeader from "../components/PageHeader";
import TicktacActions from "../components/TicktacActions";
import UserDropdown from "../components/UserDropdown";
import RecentActivities from "../components/RecentActivities";
import Modal from "../components/Modal";
import DataTable from "../components/DataTable";
import DataTableRow from "../components/DataTableRow";
import DataTableCell from "../components/DataTableCell";
import EmptyState from "../components/EmptyState";
import Footer from "../components/Footer";

const DemoOverview: React.FC = () => {
  const [showModal, setShowModal] = React.useState(false);

  return (
    <PageWrapper 
      headerTitle="Demo Overview" 
      headerActions={
        <>
          <TicktacActions />
          <RecentActivities />
          <UserDropdown />
        </>
      }
    >
      <PageHeader 
        pretitle="Komponenten Demo" 
        title="Kimai React Komponenten" 
        subtitle="Übersicht aller neuen UI-Komponenten"
      />

      <div className="row">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Header-Komponenten</h3>
            </div>
            <div className="card-body">
              <h4>TicktacActions</h4>
              <p>Start/Stop Timer für Zeiterfassung:</p>
              <TicktacActions />
              
              <h4 className="mt-4">UserDropdown</h4>
              <p>Benutzermenü mit Dropdown:</p>
              <UserDropdown />
              
              <h4 className="mt-4">RecentActivities</h4>
              <p>Aktivitäten-Icons:</p>
              <RecentActivities />
            </div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Modal Demo</h3>
            </div>
            <div className="card-body">
              <p>Klicke den Button, um ein Modal zu öffnen:</p>
              <button 
                className="btn btn-primary" 
                onClick={() => setShowModal(true)}
              >
                Modal öffnen
              </button>
              
              <Modal 
                title="Demo Modal" 
                show={showModal} 
                onClose={() => setShowModal(false)}
                footer={
                  <div>
                    <button className="btn btn-secondary me-2" onClick={() => setShowModal(false)}>
                      Abbrechen
                    </button>
                    <button className="btn btn-primary" onClick={() => setShowModal(false)}>
                      Bestätigen
                    </button>
                  </div>
                }
              >
                <p>Dies ist ein Beispiel-Modal mit benutzerdefiniertem Footer.</p>
                <p>Du kannst hier beliebigen Inhalt einfügen.</p>
              </Modal>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">DataTable Demo</h3>
            </div>
            <div className="card-body">
              <DataTable columns={["ID", "Name", "Status", "Aktionen"]}>
                <DataTableRow>
                  <DataTableCell>1</DataTableCell>
                  <DataTableCell>Projekt Alpha</DataTableCell>
                  <DataTableCell><span className="badge bg-success">Aktiv</span></DataTableCell>
                  <DataTableCell>
                    <button className="btn btn-sm btn-outline-primary">Bearbeiten</button>
                  </DataTableCell>
                </DataTableRow>
                <DataTableRow>
                  <DataTableCell>2</DataTableCell>
                  <DataTableCell>Projekt Beta</DataTableCell>
                  <DataTableCell><span className="badge bg-warning">Pausiert</span></DataTableCell>
                  <DataTableCell>
                    <button className="btn btn-sm btn-outline-primary">Bearbeiten</button>
                  </DataTableCell>
                </DataTableRow>
                <DataTableRow>
                  <DataTableCell>3</DataTableCell>
                  <DataTableCell>Projekt Gamma</DataTableCell>
                  <DataTableCell><span className="badge bg-danger">Beendet</span></DataTableCell>
                  <DataTableCell>
                    <button className="btn btn-sm btn-outline-primary">Bearbeiten</button>
                  </DataTableCell>
                </DataTableRow>
              </DataTable>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">EmptyState Demo</h3>
            </div>
            <div className="card-body">
              <EmptyState 
                icon="fas fa-inbox"
                title="Keine Daten gefunden"
                subtitle="Es wurden noch keine Einträge erstellt."
              />
            </div>
          </div>
        </div>
        
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Footer Demo</h3>
            </div>
            <div className="card-body">
              <p>Der Footer wird normalerweise am Ende der Seite angezeigt.</p>
              <Footer />
            </div>
          </div>
        </div>
      </div>
    </PageWrapper>
  );
};

export default DemoOverview; 