import React, { useState } from "react";
import PageWrapper from "../components/PageWrapper";
import PageHeader from "../components/PageHeader";
import TicktacActions from "../components/TicktacActions";
import UserDropdown from "../components/UserDropdown";
import RecentActivities from "../components/RecentActivities";
import DataTable from "../components/DataTable";
import DataTableRow from "../components/DataTableRow";
import DataTableCell from "../components/DataTableCell";
import Modal from "../components/Modal";
import EmptyState from "../components/EmptyState";

interface TimesheetEntry {
  id: number;
  date: string;
  startTime: string;
  endTime: string;
  duration: string;
  project: string;
  activity: string;
  description: string;
  billable: boolean;
}

const TimesheetDemo: React.FC = () => {
  const [entries, setEntries] = useState<TimesheetEntry[]>([
    {
      id: 1,
      date: "2024-01-15",
      startTime: "09:00",
      endTime: "12:00",
      duration: "3:00",
      project: "Website Relaunch",
      activity: "Frontend Development",
      description: "React-Komponenten implementiert",
      billable: true
    },
    {
      id: 2,
      date: "2024-01-15",
      startTime: "13:00",
      endTime: "17:00",
      duration: "4:00",
      project: "Website Relaunch",
      activity: "Backend Development",
      description: "API-Endpoints erstellt",
      billable: true
    },
    {
      id: 3,
      date: "2024-01-16",
      startTime: "08:30",
      endTime: "11:30",
      duration: "3:00",
      project: "Mobile App",
      activity: "UI/UX Design",
      description: "Wireframes erstellt",
      billable: false
    }
  ]);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newEntry, setNewEntry] = useState({
    date: "",
    startTime: "",
    endTime: "",
    project: "",
    activity: "",
    description: "",
    billable: true
  });

  const handleCreateEntry = () => {
    const entry: TimesheetEntry = {
      id: entries.length + 1,
      ...newEntry,
      duration: "0:00" // Vereinfacht für Demo
    };
    setEntries([...entries, entry]);
    setShowCreateModal(false);
    setNewEntry({
      date: "",
      startTime: "",
      endTime: "",
      project: "",
      activity: "",
      description: "",
      billable: true
    });
  };

  const totalDuration = entries.reduce((sum, entry) => {
    const [hours, minutes] = entry.duration.split(':').map(Number);
    return sum + hours * 60 + minutes;
  }, 0);

  const totalHours = Math.floor(totalDuration / 60);
  const totalMinutes = totalDuration % 60;

  return (
    <PageWrapper 
      headerTitle="Meine Zeiten" 
      headerActions={
        <>
          <TicktacActions />
          <RecentActivities />
          <UserDropdown />
        </>
      }
    >
      <PageHeader 
        pretitle="Zeiterfassung" 
        title="Meine Zeiten" 
        subtitle={`Gesamt: ${totalHours}:${totalMinutes.toString().padStart(2, '0')} Stunden`}
      />

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <div className="row align-items-center">
                <div className="col">
                  <h3 className="card-title">Zeiteinträge</h3>
                </div>
                <div className="col-auto">
                  <button 
                    className="btn btn-primary" 
                    onClick={() => setShowCreateModal(true)}
                  >
                    <i className="fas fa-plus me-2"></i>
                    Neuer Eintrag
                  </button>
                </div>
              </div>
            </div>
            <div className="card-body">
              {entries.length > 0 ? (
                <DataTable columns={["Datum", "Start", "Ende", "Dauer", "Projekt", "Aktivität", "Beschreibung", "Fakturierbar", "Aktionen"]}>
                  {entries.map((entry) => (
                    <DataTableRow key={entry.id}>
                      <DataTableCell>{entry.date}</DataTableCell>
                      <DataTableCell>{entry.startTime}</DataTableCell>
                      <DataTableCell>{entry.endTime}</DataTableCell>
                      <DataTableCell>{entry.duration}</DataTableCell>
                      <DataTableCell>{entry.project}</DataTableCell>
                      <DataTableCell>{entry.activity}</DataTableCell>
                      <DataTableCell>{entry.description}</DataTableCell>
                      <DataTableCell>
                        <span className={`badge bg-${entry.billable ? 'success' : 'secondary'}`}>
                          {entry.billable ? 'Ja' : 'Nein'}
                        </span>
                      </DataTableCell>
                      <DataTableCell>
                        <button className="btn btn-sm btn-outline-primary me-1">
                          <i className="fas fa-edit"></i>
                        </button>
                        <button className="btn btn-sm btn-outline-danger">
                          <i className="fas fa-trash"></i>
                        </button>
                      </DataTableCell>
                    </DataTableRow>
                  ))}
                </DataTable>
              ) : (
                <EmptyState 
                  icon="fas fa-clock"
                  title="Keine Zeiteinträge"
                  subtitle="Erstelle deinen ersten Zeiteintrag, um zu beginnen."
                />
              )}
            </div>
          </div>
        </div>
      </div>

      <Modal 
        title="Neuer Zeiteintrag" 
        show={showCreateModal} 
        onClose={() => setShowCreateModal(false)}
        footer={
          <div>
            <button className="btn btn-secondary me-2" onClick={() => setShowCreateModal(false)}>
              Abbrechen
            </button>
            <button className="btn btn-primary" onClick={handleCreateEntry}>
              Erstellen
            </button>
          </div>
        }
      >
        <div className="row">
          <div className="col-md-6">
            <div className="mb-3">
              <label className="form-label">Datum</label>
              <input 
                type="date" 
                className="form-control" 
                value={newEntry.date}
                onChange={(e) => setNewEntry({...newEntry, date: e.target.value})}
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="mb-3">
              <label className="form-label">Projekt</label>
              <input 
                type="text" 
                className="form-control" 
                value={newEntry.project}
                onChange={(e) => setNewEntry({...newEntry, project: e.target.value})}
              />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-6">
            <div className="mb-3">
              <label className="form-label">Startzeit</label>
              <input 
                type="time" 
                className="form-control" 
                value={newEntry.startTime}
                onChange={(e) => setNewEntry({...newEntry, startTime: e.target.value})}
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="mb-3">
              <label className="form-label">Endzeit</label>
              <input 
                type="time" 
                className="form-control" 
                value={newEntry.endTime}
                onChange={(e) => setNewEntry({...newEntry, endTime: e.target.value})}
              />
            </div>
          </div>
        </div>
        <div className="mb-3">
          <label className="form-label">Aktivität</label>
          <input 
            type="text" 
            className="form-control" 
            value={newEntry.activity}
            onChange={(e) => setNewEntry({...newEntry, activity: e.target.value})}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Beschreibung</label>
          <textarea 
            className="form-control" 
            rows={3}
            value={newEntry.description}
            onChange={(e) => setNewEntry({...newEntry, description: e.target.value})}
          />
        </div>
        <div className="mb-3">
          <div className="form-check">
            <input 
              type="checkbox" 
              className="form-check-input" 
              checked={newEntry.billable}
              onChange={(e) => setNewEntry({...newEntry, billable: e.target.checked})}
            />
            <label className="form-check-label">Fakturierbar</label>
          </div>
        </div>
      </Modal>
    </PageWrapper>
  );
};

export default TimesheetDemo; 