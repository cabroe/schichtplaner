import React from "react";
import PageWrapper from "../components/PageWrapper";
import Footer from "../components/Footer";

const LayoutDemo: React.FC = () => {
  return (
    <PageWrapper 
      headerTitle="Layout Demo" 
      headerActions={
        <div className="d-flex align-items-center">
          <span className="badge bg-success me-2">Online</span>
          <button className="btn btn-outline-secondary btn-sm">Einstellungen</button>
        </div>
      }
    >
      <div className="page-header d-print-none">
        <div className="page-pretitle">Layout & Design</div>
        <h2 className="page-title">Kimai React Layout</h2>
        <div className="page-subtitle text-body-secondary mt-1">
          Demonstration verschiedener Layout-Komponenten und deren Zusammenspiel
        </div>
      </div>

      <div className="row">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Layout-Struktur</h3>
            </div>
            <div className="card-body">
              <h4>Komponenten-Hierarchie</h4>
              <pre className="bg-light p-3 rounded">
{`PageWrapper
├── Sidebar (Vertical Navbar)
├── Header (Horizontal Navbar)
└── PageBody
    ├── PageHeader
    ├── Content
    └── Footer`}
              </pre>
              
              <h4 className="mt-4">Responsive Verhalten</h4>
              <ul>
                <li><strong>Desktop:</strong> Sidebar + Header + Content</li>
                <li><strong>Mobile:</strong> Hamburger-Menü + Content</li>
                <li><strong>Tablet:</strong> Angepasste Breakpoints</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">CSS-Klassen</h3>
            </div>
            <div className="card-body">
              <h4>Wichtige Tabler-Klassen</h4>
              <div className="table-responsive">
                <table className="table table-sm">
                  <thead>
                    <tr>
                      <th>Klasse</th>
                      <th>Zweck</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><code>.navbar-vertical</code></td>
                      <td>Vertikale Sidebar</td>
                    </tr>
                    <tr>
                      <td><code>.page-wrapper</code></td>
                      <td>Hauptcontainer</td>
                    </tr>
                    <tr>
                      <td><code>.page-header</code></td>
                      <td>Seitenkopf</td>
                    </tr>
                    <tr>
                      <td><code>.page-body</code></td>
                      <td>Hauptinhalt</td>
                    </tr>
                    <tr>
                      <td><code>.d-none .d-lg-flex</code></td>
                      <td>Responsive Sichtbarkeit</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Layout-Beispiele</h3>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-4">
                  <div className="card border">
                    <div className="card-body text-center">
                      <i className="fas fa-desktop fa-2x text-primary mb-3"></i>
                      <h5>Desktop Layout</h5>
                      <p className="text-muted">Sidebar + Header + Content nebeneinander</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="card border">
                    <div className="card-body text-center">
                      <i className="fas fa-tablet-alt fa-2x text-warning mb-3"></i>
                      <h5>Tablet Layout</h5>
                      <p className="text-muted">Angepasste Breakpoints für mittlere Bildschirme</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="card border">
                    <div className="card-body text-center">
                      <i className="fas fa-mobile-alt fa-2x text-success mb-3"></i>
                      <h5>Mobile Layout</h5>
                      <p className="text-muted">Hamburger-Menü + Stacked Content</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-md-8">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Verwendung</h3>
            </div>
            <div className="card-body">
              <h4>Grundlegende Verwendung</h4>
              <pre className="bg-light p-3 rounded">
{`import PageWrapper from './components-new/PageWrapper';
import PageHeader from './components-new/PageHeader';

const MyPage = () => (
  <PageWrapper headerTitle="Meine Seite">
    <PageHeader 
      pretitle="Übersicht" 
      title="Dashboard" 
      subtitle="Willkommen zurück"
    />
    <div className="row">
      <div className="col-12">
        {/* Dein Content hier */}
      </div>
    </div>
  </PageWrapper>
);`}
              </pre>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Vorteile</h3>
            </div>
            <div className="card-body">
              <ul className="list-unstyled">
                <li className="mb-2">
                  <i className="fas fa-check text-success me-2"></i>
                  Konsistentes Design
                </li>
                <li className="mb-2">
                  <i className="fas fa-check text-success me-2"></i>
                  Responsive Layout
                </li>
                <li className="mb-2">
                  <i className="fas fa-check text-success me-2"></i>
                  Wiederverwendbare Komponenten
                </li>
                <li className="mb-2">
                  <i className="fas fa-check text-success me-2"></i>
                  TypeScript Support
                </li>
                <li className="mb-2">
                  <i className="fas fa-check text-success me-2"></i>
                  Tabler/Bootstrap Integration
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </PageWrapper>
  );
};

export default LayoutDemo; 