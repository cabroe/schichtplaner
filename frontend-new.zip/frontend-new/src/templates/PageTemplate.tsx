import React from "react";
import MainTemplate from "./MainTemplate";
import PageHeader from "../components/PageHeader";

interface PageTemplateProps {
  children: React.ReactNode;
  headerTitle?: string;
  headerActions?: React.ReactNode;
  pageTitle?: string;
  pagePretitle?: string;
  pageSubtitle?: string;
}

const PageTemplate: React.FC<PageTemplateProps> = ({ 
  children, 
  headerTitle,
  headerActions,
  pageTitle,
  pagePretitle,
  pageSubtitle
}) => {
  return (
    <MainTemplate headerTitle={headerTitle} headerActions={headerActions}>
      {(pageTitle || pagePretitle || pageSubtitle) && (
        <PageHeader 
          title={pageTitle || ""}
          pretitle={pagePretitle}
          subtitle={pageSubtitle}
        />
      )}
      {children}
    </MainTemplate>
  );
};

export default PageTemplate; 