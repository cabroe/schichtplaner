import React from "react";

interface SimpleTemplateProps {
  children: React.ReactNode;
}

const SimpleTemplate: React.FC<SimpleTemplateProps> = ({ children }) => {
  return (
    <div className="page page-center">
      <div className="container container-tight py-4">
        <div className="text-center mb-4">
          <h1 className="text-white">
            <i className="fas fa-calendar-alt me-2" style={{ fontSize: "1.5rem" }}></i>
            Schichtplaner
          </h1>
        </div>
        {children}
      </div>
    </div>
  );
};

export default SimpleTemplate; 