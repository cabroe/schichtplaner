import React from "react";
import { SimpleTemplate, MainTemplate, LoginTemplate, PageTemplate } from "./index";

// Demo für SimpleTemplate
export const SimpleTemplateDemo: React.FC = () => (
  <SimpleTemplate>
    <div className="card">
      <div className="card-body text-center">
        <h3>SimpleTemplate Demo</h3>
        <p>Dieses Template ist für zentrierte Inhalte wie Login-Seiten gedacht.</p>
        <button className="btn btn-primary">Beispiel Button</button>
      </div>
    </div>
  </SimpleTemplate>
);

// Demo für LoginTemplate
export const LoginTemplateDemo: React.FC = () => (
  <LoginTemplate 
    title="Anmelden" 
    subtitle="Geben Sie Ihre Anmeldedaten ein"
  >
    <form>
      <div className="mb-3">
        <label className="form-label">Benutzername</label>
        <input type="text" className="form-control" placeholder="Benutzername" />
      </div>
      <div className="mb-3">
        <label className="form-label">Passwort</label>
        <input type="password" className="form-control" placeholder="Passwort" />
      </div>
      <div className="mb-3">
        <div className="form-check">
          <input type="checkbox" className="form-check-input" />
          <label className="form-check-label">Angemeldet bleiben</label>
        </div>
      </div>
      <div className="d-grid">
        <button type="submit" className="btn btn-primary">Anmelden</button>
      </div>
    </form>
  </LoginTemplate>
);

// Demo für MainTemplate
export const MainTemplateDemo: React.FC = () => (
  <MainTemplate headerTitle="MainTemplate Demo">
    <div className="row">
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">MainTemplate Demo</h3>
          </div>
          <div className="card-body">
            <p>Dieses Template enthält das vollständige Kimai-Layout mit Sidebar und Header.</p>
            <p>Es ist für alle Hauptseiten der Anwendung gedacht.</p>
          </div>
        </div>
      </div>
    </div>
  </MainTemplate>
);

// Demo für PageTemplate
export const PageTemplateDemo: React.FC = () => (
  <PageTemplate 
    headerTitle="PageTemplate Demo"
    pagePretitle="Übersicht"
    pageTitle="Dashboard"
    pageSubtitle="Willkommen zurück"
  >
    <div className="row">
      <div className="col-md-6">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Seite mit PageHeader</h3>
          </div>
          <div className="card-body">
            <p>Dieses Template erweitert MainTemplate um einen PageHeader.</p>
            <p>Perfekt für Seiten mit Titel, Pretitle und Subtitle.</p>
          </div>
        </div>
      </div>
      <div className="col-md-6">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Verwendung</h3>
          </div>
            <div className="card-body">
              <pre className="bg-light p-3 rounded">
{`<PageTemplate 
  headerTitle="Meine Seite"
  pagePretitle="Übersicht"
  pageTitle="Dashboard"
  pageSubtitle="Willkommen zurück"
>
  {/* Dein Content */}
</PageTemplate>`}
              </pre>
            </div>
        </div>
      </div>
    </div>
  </PageTemplate>
); 