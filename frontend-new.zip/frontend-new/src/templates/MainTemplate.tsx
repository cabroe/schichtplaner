import React from "react";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";
import TicktacActions from "../components/TicktacActions";
import UserDropdown from "../components/UserDropdown";
import RecentActivities from "../components/RecentActivities";

interface MainTemplateProps {
  children: React.ReactNode;
  headerTitle?: string;
  headerActions?: React.ReactNode;
}

const MainTemplate: React.FC<MainTemplateProps> = ({ 
  children, 
  headerTitle, 
  headerActions 
}) => {
  return (
    <div className="page">
      {/* Sidebar - Kimai's vertical navbar */}
      <Sidebar />

      {/* Header - Kimai's horizontal navbar */}
      <Header title={headerTitle}>
        {headerActions || (
          <>
            <TicktacActions />
            <RecentActivities />
            <UserDropdown />
          </>
        )}
      </Header>
      
      {/* Page Wrapper - Kimai's main content area */}
      <div className="page-wrapper">
        
        {/* Page Body - Kimai's content area */}
        <div className="page-body">
          <div className="container-fluid">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainTemplate; 