export { default as SimpleTemplate } from './SimpleTemplate';
export { default as MainTemplate } from './MainTemplate';
export { default as LoginTemplate } from './LoginTemplate';
export { default as PageTemplate } from './PageTemplate'; 