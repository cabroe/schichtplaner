import React from "react";
import SimpleTemplate from "./SimpleTemplate";

interface LoginTemplateProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
}

const LoginTemplate: React.FC<LoginTemplateProps> = ({ 
  children, 
  title = "Anmelden",
  subtitle 
}) => {
  return (
    <SimpleTemplate>
      <div className="card" style={{ minWidth: "320px", maxWidth: "400px", width: "90vw" }}>
        <div className="card-body p-4 p-md-5">
          <h2 className="card-title text-center mb-4">
            {title}
          </h2>
          {subtitle && (
            <p className="text-muted text-center mb-4">
              {subtitle}
            </p>
          )}
          {children}
        </div>
      </div>
    </SimpleTemplate>
  );
};

export default LoginTemplate; 