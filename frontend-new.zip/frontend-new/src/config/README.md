# Navigation Configuration

Diese Datei dokumentiert die Navigation-Konfiguration für die Kimai React App.

## Übersicht

Die Navigation wird zentral in `navigation.ts` konfiguriert und bietet folgende Features:

- **Berechtigungsbasierte Navigation**: Menüpunkte können basierend auf Benutzerberechtigungen angezeigt/versteckt werden
- **Externe Links**: Links zu externen Seiten öffnen sich in einem neuen Tab
- **Badges**: Zusätzliche Informationen wie Anzahl aktiver Zeiterfassungen
- **Deaktivierte Links**: Temporär nicht verfügbare Funktionen
- **Aktive Navigation**: Automatische Hervorhebung des aktuellen Pfads

## Struktur

### NavigationItem Interface

```typescript
interface NavigationItem {
  id: string;           // Eindeutige ID
  label: string;        // Anzeigename
  path: string;         // URL-Pfad oder externe URL
  icon?: string;        // FontAwesome Icon-Klasse
  badge?: string;       // Badge-Text (z.B. "3" für Anzahl)
  children?: NavigationItem[]; // Untermenü (nicht implementiert)
  permissions?: string[]; // Benötigte Berechtigungen
  external?: boolean;   // Externer Link
  disabled?: boolean;   // Deaktivierter Link
}
```

### NavigationSection Interface

```typescript
interface NavigationSection {
  id: string;           // Eindeutige ID
  title?: string;       // Sektions-Titel
  items: NavigationItem[]; // Navigation-Items
  collapsed?: boolean;  // Sektion einklappbar (nicht implementiert)
}
```

## Verwendung

### Grundlegende Verwendung

```tsx
import Sidebar from './components/Sidebar';

// Ohne Berechtigungen (alle Menüpunkte sichtbar)
<Sidebar />

// Mit Benutzerberechtigungen
<Sidebar userPermissions={['admin', 'user']} />
```

### Navigation konfigurieren

```typescript
// Neue Navigation-Sektion hinzufügen
{
  id: 'custom',
  title: 'Meine Sektion',
  items: [
    {
      id: 'my-page',
      label: 'Meine Seite',
      path: '/my-page',
      icon: 'fas fa-star'
    }
  ]
}
```

### Berechtigungen verwenden

```typescript
// Nur für Administratoren sichtbar
{
  id: 'admin-only',
  label: 'Admin Funktion',
  path: '/admin',
  icon: 'fas fa-cog',
  permissions: ['admin']
}
```

### Externe Links

```typescript
// Öffnet in neuem Tab
{
  id: 'docs',
  label: 'Dokumentation',
  path: 'https://docs.example.com',
  icon: 'fas fa-book',
  external: true
}
```

### Badges verwenden

```typescript
// Zeigt Anzahl aktiver Zeiterfassungen
{
  id: 'timesheet',
  label: 'Zeiterfassung',
  path: '/timesheet',
  icon: 'fas fa-clock',
  badge: '3' // Dynamisch aus API laden
}
```

## Helper Functions

### getAllNavigationItems()
Gibt alle Navigation-Items als flache Liste zurück.

### findNavigationItemByPath(path: string)
Findet ein Navigation-Item anhand des Pfads.

### getNavigationItemById(id: string)
Findet ein Navigation-Item anhand der ID.

### isNavigationItemActive(item: NavigationItem, currentPath: string)
Prüft, ob ein Navigation-Item aktiv ist.

### filterNavigationByPermissions(navigation: NavigationSection[], userPermissions: string[])
Filtert Navigation basierend auf Benutzerberechtigungen.

### getBreadcrumbNavigation(currentPath: string)
Erstellt Breadcrumb-Navigation für den aktuellen Pfad.

## Beispiele

### Dynamische Badges

```typescript
// Badge dynamisch aus API laden
const [activeTimesheets, setActiveTimesheets] = useState(0);

useEffect(() => {
  // API-Call für aktive Zeiterfassungen
  fetchActiveTimesheets().then(count => {
    setActiveTimesheets(count);
  });
}, []);

// In der Navigation-Konfiguration
{
  id: 'timesheet',
  label: 'Zeiterfassung',
  path: '/timesheet',
  icon: 'fas fa-clock',
  badge: activeTimesheets > 0 ? activeTimesheets.toString() : undefined
}
```

### Berechtigungsbasierte Navigation

```typescript
// Benutzerberechtigungen aus Auth-Context
const { user } = useAuth();
const userPermissions = user?.permissions || [];

// Sidebar mit gefilterter Navigation
<Sidebar userPermissions={userPermissions} />
```

## Erweiterungen

### Untermenüs (Nested Navigation)

```typescript
{
  id: 'reports',
  label: 'Berichte',
  path: '/reports',
  icon: 'fas fa-chart-bar',
  children: [
    {
      id: 'reports-monthly',
      label: 'Monatsbericht',
      path: '/reports/monthly',
      icon: 'fas fa-calendar'
    },
    {
      id: 'reports-yearly',
      label: 'Jahresbericht',
      path: '/reports/yearly',
      icon: 'fas fa-calendar-alt'
    }
  ]
}
```

### Collapsible Sections

```typescript
{
  id: 'management',
  title: 'Verwaltung',
  collapsed: false, // Standard: false
  items: [...]
}
```

## Best Practices

1. **Konsistente IDs**: Verwende kebab-case für IDs (z.B. `user-management`)
2. **Bedeutungsvolle Labels**: Verwende klare, benutzerfreundliche Labels
3. **Icon-Konsistenz**: Verwende FontAwesome Icons konsequent
4. **Berechtigungen**: Definiere Berechtigungen für sensitive Funktionen
5. **Externe Links**: Markiere externe Links mit `external: true`
6. **Badges**: Verwende Badges nur für wichtige Informationen
7. **Deaktivierte Links**: Verwende `disabled: true` für temporär nicht verfügbare Features 