// Navigation Configuration
// Centralized navigation configuration for the application

export interface NavigationItem {
  id: string;
  label: string;
  path: string;
  icon?: string;
  badge?: string;
  children?: NavigationItem[];
  permissions?: string[];
  external?: boolean;
  disabled?: boolean;
}

export interface NavigationSection {
  id: string;
  title?: string;
  items: NavigationItem[];
  collapsed?: boolean;
}

// Main navigation configuration
export const navigationConfig: NavigationSection[] = [
  {
    id: 'main',
    items: [
      {
        id: 'dashboard',
        label: 'Dashboard',
        path: '/',
        icon: 'fas fa-tachometer-alt'
      },
      {
        id: 'timesheet',
        label: 'Zeiterfassung',
        path: '/timesheet',
        icon: 'fas fa-clock',
        badge: '3' // Beispiel für aktive Zeiterfassungen
      },
      {
        id: 'reports',
        label: 'Berichte',
        path: '/reports',
        icon: 'fas fa-chart-bar'
      }
    ]
  },
  {
    id: 'management',
    title: 'Verwaltung',
    items: [
      {
        id: 'projects',
        label: 'Projekte',
        path: '/projects',
        icon: 'fas fa-project-diagram'
      },
      {
        id: 'customers',
        label: 'Kunden',
        path: '/customers',
        icon: 'fas fa-users'
      },
      {
        id: 'activities',
        label: 'Aktivitäten',
        path: '/activities',
        icon: 'fas fa-tasks'
      },
      {
        id: 'tags',
        label: 'Tags',
        path: '/tags',
        icon: 'fas fa-tags'
      }
    ]
  },
  {
    id: 'administration',
    title: 'Administration',
    items: [
      {
        id: 'users',
        label: 'Benutzer',
        path: '/users',
        icon: 'fas fa-user-cog',
        permissions: ['admin']
      },
      {
        id: 'settings',
        label: 'Einstellungen',
        path: '/settings',
        icon: 'fas fa-cog'
      },
      {
        id: 'system',
        label: 'System',
        path: '/system',
        icon: 'fas fa-server',
        permissions: ['admin']
      }
    ]
  },
  {
    id: 'external',
    title: 'Externe Links',
    items: [
      {
        id: 'documentation',
        label: 'Dokumentation',
        path: 'https://docs.kimai.org',
        icon: 'fas fa-book',
        external: true
      },
      {
        id: 'support',
        label: 'Support',
        path: 'https://support.kimai.org',
        icon: 'fas fa-life-ring',
        external: true
      }
    ]
  }
];

// Helper function to get all navigation items flattened
export const getAllNavigationItems = (): NavigationItem[] => {
  return navigationConfig.flatMap(section => section.items);
};

// Helper function to find navigation item by path
export const findNavigationItemByPath = (path: string): NavigationItem | undefined => {
  return getAllNavigationItems().find(item => item.path === path);
};

// Helper function to get navigation item by id
export const getNavigationItemById = (id: string): NavigationItem | undefined => {
  return getAllNavigationItems().find(item => item.id === id);
};

// Helper function to check if navigation item is active
export const isNavigationItemActive = (item: NavigationItem, currentPath: string): boolean => {
  if (item.external) return false;
  return item.path === currentPath || currentPath.startsWith(item.path + '/');
};

// Helper function to filter navigation by permissions
export const filterNavigationByPermissions = (
  navigation: NavigationSection[],
  userPermissions: string[] = []
): NavigationSection[] => {
  return navigation.map(section => ({
    ...section,
    items: section.items.filter(item => {
      if (!item.permissions) return true;
      return item.permissions.some(permission => userPermissions.includes(permission));
    })
  })).filter(section => section.items.length > 0);
};

// Helper function to get breadcrumb navigation
export const getBreadcrumbNavigation = (currentPath: string): NavigationItem[] => {
  const breadcrumbs: NavigationItem[] = [];
  const allItems = getAllNavigationItems();
  
  let path = currentPath;
  while (path !== '/') {
    const item = allItems.find(navItem => path.startsWith(navItem.path));
    if (item && !item.external) {
      breadcrumbs.unshift(item);
      path = item.path;
    } else {
      break;
    }
  }
  
  return breadcrumbs;
}; 